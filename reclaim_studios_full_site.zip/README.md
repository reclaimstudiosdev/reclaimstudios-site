# Reclaim Studios Site

A minimalist dark-themed static site for the Unity Asset Store publisher requirements.

## Deploy (GitHub Pages)
1. Create a public repo, e.g. `reclaimstudios-site`
2. Upload all files (keep the `/assets` folder)
3. Settings → Pages → Deploy from branch → `main` → `/ (root)`
4. Replace `USERNAME` in `sitemap.txt` with your GitHub username

## Customize
- Replace `/assets/img/logo.svg` if you have a new logo
- Edit colors in `/assets/css/site.css`
- Update contact email across pages
